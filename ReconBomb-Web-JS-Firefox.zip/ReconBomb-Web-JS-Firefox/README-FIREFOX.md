# ReconBomb Web JS — Build Firefox (v3.0)

Variante para **Firefox**. Diferencias respecto a la de Chrome:
- `background` como *event page* (`scripts: [idb.js, background.js]`), no service worker.
- `injected.js` se inyecta como `<script>` desde `content.js` y se declara en
  `web_accessible_resources` (Firefox no soporta `world:"MAIN"` en el manifest).

## Instalar (temporal, para probar)
1. Abre `about:debugging#/runtime/this-firefox`
2. **Cargar complemento temporal…** (Load Temporary Add-on)
3. Selecciona el archivo **`manifest.json`** de la carpeta `ReconBomb-Web-JS-Firefox`
   (no el zip; descomprímelo primero).
4. Aparece el icono. El complemento se quita al cerrar Firefox (normal en modo temporal).

> Instalación permanente: requiere firmar el .xpi en addons.mozilla.org (AMO).
> Para desarrollo, el modo temporal es suficiente.

## Probar
Usa `test-reconbomb.html`. Firefox no siempre ejecuta content scripts sobre
`file://`, así que lo más fiable es servirlo por HTTP local:

```bash
cd carpeta_donde_esta_el_html
python3 -m http.server 8000
# abre http://localhost:8000/test-reconbomb.html
```

Luego: popup → **Tracker ON**, **Guardar ON**, **Objetivo** = `sendText`,
abre la consola (F12) y pulsa los botones. Mira **Ver registros**.

## Notas
- Con una CSP de página muy estricta, la inyección del `<script>` puede
  bloquearse (limitación inherente a este método en Firefox).
- `chrome.*` funciona en Firefox como alias de `browser.*`.
