/* background.js (Firefox) — event page.
   idb.js se carga antes en el manifest ("background.scripts"), así que RBDB ya
   es global (no se usa importScripts, que solo existe en service workers). */
'use strict';

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg && msg.type === 'rb_call' && msg.record) {
    const rec = msg.record;
    if (sender && sender.tab && sender.tab.url) rec.url = sender.tab.url;
    RBDB.add(rec).catch(() => {});
  }
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['trackerEnabled', 'trackerSave', 'trackerFilter', 'trackerHookAll'], (r) => {
    const defaults = {};
    if (r.trackerEnabled === undefined) defaults.trackerEnabled = true;
    if (r.trackerSave === undefined) defaults.trackerSave = false;
    if (r.trackerFilter === undefined) defaults.trackerFilter = '';
    if (r.trackerHookAll === undefined) defaults.trackerHookAll = false;
    if (Object.keys(defaults).length) chrome.storage.local.set(defaults);
  });
});
