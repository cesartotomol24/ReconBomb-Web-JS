/* content.js (Firefox) — puente (mundo ISOLATED).
   A diferencia de Chrome, Firefox no soporta "world":"MAIN" en el manifest,
   así que aquí inyectamos injected.js como <script> en la página (contexto MAIN).
   El resto (estado + persistencia) es idéntico. */
'use strict';

// --- Inyectar el hooker en el contexto de la página ----------------------
(function injectMain() {
  try {
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL('injected.js');
    s.async = false;
    s.onload = function () { s.remove(); };
    (document.head || document.documentElement).appendChild(s);
  } catch (e) { /* algunas CSP muy estrictas pueden bloquearlo */ }
})();

const cache = { enabled: true, save: false, filter: '', hookAll: false };

function loadState(cb) {
  chrome.storage.local.get(['trackerEnabled', 'trackerSave', 'trackerFilter', 'trackerHookAll'], (r) => {
    cache.enabled = r.trackerEnabled !== false;
    cache.save = r.trackerSave === true;
    cache.filter = r.trackerFilter || '';
    cache.hookAll = r.trackerHookAll === true;
    if (cb) cb();
  });
}

function pushState() {
  window.postMessage(
    {
      source: 'reconbomb-cs',
      type: '__RB_STATE__',
      enabled: cache.enabled,
      filter: cache.filter,
      hookAll: cache.hookAll
    },
    '*'
  );
}

window.addEventListener('message', (e) => {
  if (e.source !== window) return;
  const d = e.data;
  if (!d || typeof d !== 'object') return;

  if (d.type === '__RB_GET_STATE__') {
    loadState(pushState);
  } else if (d.type === '__RB_CALL__' && d.source === 'reconbomb') {
    if (cache.save && d.record) {
      try { chrome.runtime.sendMessage({ type: 'rb_call', record: d.record }); } catch (err) {}
    }
  }
});

loadState(() => {
  pushState();
  setTimeout(pushState, 300);
});

chrome.storage.onChanged.addListener((ch, area) => {
  if (area !== 'local') return;
  let stateChanged = false;
  if ('trackerEnabled' in ch) { cache.enabled = ch.trackerEnabled.newValue !== false; stateChanged = true; }
  if ('trackerSave' in ch) { cache.save = ch.trackerSave.newValue === true; }
  if ('trackerFilter' in ch) { cache.filter = ch.trackerFilter.newValue || ''; stateChanged = true; }
  if ('trackerHookAll' in ch) { cache.hookAll = ch.trackerHookAll.newValue === true; stateChanged = true; }
  if (stateChanged) pushState();
});
