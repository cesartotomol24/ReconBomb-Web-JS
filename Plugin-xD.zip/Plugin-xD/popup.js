const btn = document.getElementById('toggleBtn');
 
function updateUI(active) {
  btn.textContent = active ? '🟢 Tracker: ON' : '⚪ Tracker: OFF';
  btn.className = active ? 'active' : 'inactive';
}
 
chrome.storage.local.get(['trackerEnabled'], (res) => {
  const active = res.trackerEnabled !== false;
  updateUI(active);
});
 
btn.addEventListener('click', () => {
  chrome.storage.local.get(['trackerEnabled'], (res) => {
    const newState = !(res.trackerEnabled !== false);
    chrome.storage.local.set({ trackerEnabled: newState }, () => {
      updateUI(newState);
    });
  });
});