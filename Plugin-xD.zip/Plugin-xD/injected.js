(function initStealthTracker() {
  'use strict';
 
  let isEnabled = true;
  const trackedFunctions = new WeakSet();
 
  // 1. Escuchar actualizaciones de estado desde content.js
  window.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'TRACKER_TOGGLE') {
      isEnabled = event.data.enabled;
      console.log(
        `%c${isEnabled ? '🟢 RASTREADOR ACTIVADO' : '⚪ RASTREADOR DESACTIVADO'}`,
        `color: white; background: ${isEnabled ? '#10b981' : '#6b7280'}; font-weight: bold; padding: 4px 8px; border-radius: 4px;`
      );
    }
  });
 
  // 2. Solicitar inmediatamente el estado guardado al cargar
  window.postMessage({ type: 'TRACKER_GET_STATE' }, '*');
 
  function formatArg(arg) {
    if (typeof arg === 'string') return `"${arg}"`;
    if (typeof arg === 'function') return '[Function]';
    if (arg === undefined) return 'undefined';
    if (arg === null) return 'null';
    try { return JSON.stringify(arg); } catch (e) { return String(arg); }
  }
 
  function hookGlobalFunctions() {
    for (let prop in window) {
      try {
        if (
          typeof window[prop] === 'function' &&
          !window[prop].toString().includes('[native code]')
        ) {
          if (trackedFunctions.has(window[prop])) continue;
 
          const orig = window[prop];
          const wrapped = function (...args) {
            if (!isEnabled) {
              return orig.apply(this, args);
            }
 
            const formattedArgs = args.map(formatArg).join(', ');
            let result;
 
            try {
              result = orig.apply(this, args);
 
              if (result && typeof result.then === 'function') {
                console.log(
                  `%c🚀 ${prop}(${formattedArgs})`,
                  'color: #0d6efd; font-weight: bold; background: #eef3fc; padding: 2px 6px; border-radius: 3px;',
                  '➜ Promesa pendiente...'
                );
                result.then(asyncRes => {
                  if (isEnabled) {
                    console.log(
                      `%c  └─ ➔ Resultado Async de ${prop}():`,
                      'color: #059669; font-weight: bold;',
                      asyncRes
                    );
                  }
                }).catch(asyncErr => {
                  if (isEnabled) {
                    console.error(`  └─ ❌ Error Async en ${prop}():`, asyncErr);
                  }
                });
              } else {
                console.log(
                  `%c🚀 ${prop}(${formattedArgs})`,
                  'color: #0d6efd; font-weight: bold; background: #eef3fc; padding: 2px 6px; border-radius: 3px;',
                  '➜ Resultado:', result
                );
              }
 
              return result;
            } catch (err) {
              if (isEnabled) {
                console.error(
                  `%c❌ Excepción en ${prop}(${formattedArgs}):`,
                  'color: #dc2626; font-weight: bold;',
                  err
                );
              }
              throw err;
            }
          };
 
          try {
            Object.defineProperty(wrapped, 'name', { value: orig.name, configurable: true });
          } catch (e) {}
 
          trackedFunctions.add(wrapped);
          window[prop] = wrapped;
        }
      } catch (e) {
        // Ignorar propiedades protegidas o getters con restricciones
      }
    }
  }
 
  hookGlobalFunctions();
  setInterval(hookGlobalFunctions, 1500);
 
  console.log(
    '%c✅ RASTREADOR STEALTH LISTO',
    'color: white; background: #10b981; font-weight: bold; padding: 4px 8px; border-radius: 4px;'
  );
})();