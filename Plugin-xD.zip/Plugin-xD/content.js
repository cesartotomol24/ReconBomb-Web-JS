// Responder a la solicitud de estado inicial enviada por injected.js

window.addEventListener('message', (event) => {

  if (event.data && event.data.type === 'TRACKER_GET_STATE') {

    chrome.storage.local.get(['trackerEnabled'], (res) => {

      const enabled = res.trackerEnabled !== false;

      window.postMessage({ type: 'TRACKER_TOGGLE', enabled }, '*');

    });

  }

});
 
// Transmitir cambios en tiempo real cuando presionas el botón del Popup

chrome.storage.onChanged.addListener((changes) => {

  if (changes.trackerEnabled) {

    window.postMessage({

      type: 'TRACKER_TOGGLE',

      enabled: changes.trackerEnabled.newValue

    }, '*');

  }

});
 