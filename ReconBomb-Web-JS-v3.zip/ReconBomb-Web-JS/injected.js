/* injected.js — mundo MAIN.
   Detecta la ejecución de funciones JS en tiempo real envolviéndolas con Proxy.

   MODO SEGURO: por defecto NO envuelve nada. Solo actúa cuando hay un filtro
   (objetivos por nombre) o el "Hook de todas" está activo. Al apagar el Tracker
   o quitar un objetivo, RESTAURA la función original (no deja la página alterada). */
(function initTracker() {
  'use strict';

  let isEnabled = true;
  let hookAll = false;              // si true y sin filtro: envuelve todos los globals
  let filterTokens = [];            // objetivos por nombre/substring; vacío = ninguno (modo seguro)
  const wrapped = new WeakSet();    // proxies creados por nosotros
  const originals = new Map();      // prop -> { fn, desc }  para poder restaurar

  // ---- Estado desde content.js --------------------------------------------
  window.addEventListener('message', (e) => {
    if (e.source !== window) return;
    const d = e.data;
    if (!d || d.type !== '__RB_STATE__' || d.source !== 'reconbomb-cs') return;

    isEnabled = d.enabled !== false;
    hookAll = d.hookAll === true;
    filterTokens = String(d.filter || '')
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean);

    const mode = filterTokens.length ? 'filtro: ' + filterTokens.join(', ')
      : (hookAll ? 'TODAS' : 'en espera de objetivo');
    console.log(
      `%c${isEnabled ? '🟢 RASTREADOR ACTIVADO' : '⚪ RASTREADOR DESACTIVADO'}  ·  ${mode}`,
      `color:#fff;background:${isEnabled ? '#10b981' : '#6b7280'};font-weight:bold;padding:4px 8px;border-radius:4px;`
    );
    reconcile();
  });

  window.postMessage({ source: 'reconbomb', type: '__RB_GET_STATE__' }, '*');
  setTimeout(() => window.postMessage({ source: 'reconbomb', type: '__RB_GET_STATE__' }, '*'), 400);

  // ---- Utilidades ----------------------------------------------------------
  function matchesFilter(name) {
    const n = String(name).toLowerCase();
    for (let i = 0; i < filterTokens.length; i++) {
      if (n.indexOf(filterTokens[i]) !== -1) return true;
    }
    return false;
  }

  function shouldWrap(prop) {
    if (!isEnabled) return false;
    if (filterTokens.length) return matchesFilter(prop);
    return hookAll; // sin filtro, solo si "Hook de todas" está activo
  }

  function safe(val, depth) {
    depth = depth || 0;
    try {
      if (val === null) return null;
      const t = typeof val;
      if (t === 'string') return val.length > 500 ? val.slice(0, 500) + '…(+' + (val.length - 500) + ')' : val;
      if (t === 'number' || t === 'boolean') return val;
      if (t === 'undefined') return '[undefined]';
      if (t === 'bigint') return val.toString() + 'n';
      if (t === 'symbol') return val.toString();
      if (t === 'function') return '[Function ' + (val.name || 'anon') + ']';
      if (typeof Node !== 'undefined' && val instanceof Node) {
        return '[Node <' + String(val.nodeName || '').toLowerCase() + '>]';
      }
      if (depth >= 2) return Array.isArray(val) ? '[Array]' : '[Object]';
      if (Array.isArray(val)) {
        const arr = [];
        for (let i = 0; i < val.length && i < 20; i++) arr.push(safe(val[i], depth + 1));
        if (val.length > 20) arr.push('…(+' + (val.length - 20) + ')');
        return arr;
      }
      const o = {};
      let n = 0;
      for (const k in val) {
        if (n++ >= 30) { o['…'] = '(+más)'; break; }
        try { o[k] = safe(val[k], depth + 1); } catch (e) { o[k] = '[illegible]'; }
      }
      return o;
    } catch (e) {
      return '[no serializable]';
    }
  }

  function emit(record) {
    try { window.postMessage({ source: 'reconbomb', type: '__RB_CALL__', record }, '*'); } catch (e) {}
  }

  function previewArgs(argsArr) {
    return argsArr.map((a) => {
      try { return JSON.stringify(a); } catch (e) { return String(a); }
    }).join(', ');
  }

  // ---- Ejecutar + registrar -----------------------------------------------
  function now() { return (performance && performance.now) ? performance.now() : Date.now(); }

  function run(target, thisArg, args, name, isCtor, newTarget) {
    const started = now();
    const safeArgs = [];
    try { for (let i = 0; i < args.length; i++) safeArgs.push(safe(args[i])); }
    catch (e) { safeArgs.length = 0; safeArgs.push('[args ilegibles]'); }

    console.log(
      `%c🚀 ${isCtor ? 'new ' : ''}${name}(${previewArgs(safeArgs)})`,
      'color:#0d6efd;font-weight:bold;background:#eef3fc;padding:2px 6px;border-radius:3px;'
    );

    const base = { name, ts: Date.now(), ctor: !!isCtor, args: safeArgs, url: location.href };

    let result;
    try {
      result = isCtor ? Reflect.construct(target, args, newTarget) : Reflect.apply(target, thisArg, args);
    } catch (err) {
      console.error(`%c❌ Excepción en ${name}():`, 'color:#dc2626;font-weight:bold;', err);
      emit(Object.assign({}, base, { status: 'error', error: String((err && err.message) || err), ms: Math.round(now() - started) }));
      throw err;
    }

    if (result && typeof result.then === 'function') {
      console.log(`%c  └─ ${name}() ➜ Promesa pendiente…`, 'color:#8b5cf6;font-weight:bold;');
      result.then(
        (r) => { console.log(`%c  └─ ✔ ${name}() resolvió:`, 'color:#059669;font-weight:bold;', r);
          emit(Object.assign({}, base, { status: 'resolved', result: safe(r), ms: Math.round(now() - started) })); },
        (e) => { console.error(`%c  └─ ✖ ${name}() rechazó:`, 'color:#dc2626;font-weight:bold;', e);
          emit(Object.assign({}, base, { status: 'rejected', error: String((e && e.message) || e), ms: Math.round(now() - started) })); }
      );
    } else {
      console.log(`%c  └─ ➔ ${name}() devolvió:`, 'color:#059669;font-weight:bold;', result);
      emit(Object.assign({}, base, { status: 'ok', result: safe(result), ms: Math.round(now() - started) }));
    }
    return result;
  }

  function makeProxy(fn, name) {
    const handler = {
      apply(target, thisArg, args) {
        if (!isEnabled || !shouldWrap(name)) return Reflect.apply(target, thisArg, args);
        return run(target, thisArg, args, name, false, undefined);
      },
      construct(target, args, newTarget) {
        if (!isEnabled || !shouldWrap(name)) return Reflect.construct(target, args, newTarget);
        return run(target, null, args, name, true, newTarget);
      }
    };
    const p = new Proxy(fn, handler); // conserva name, length y prototype
    wrapped.add(p);
    return p;
  }

  // ---- Instalar / restaurar hooks -----------------------------------------
  function wrapProp(prop) {
    let desc;
    try { desc = Object.getOwnPropertyDescriptor(window, prop); } catch (e) { return; }
    if (!desc || typeof desc.get === 'function') return;   // accessors fuera (posibles efectos)
    if (!desc.configurable) return;                        // no podríamos restaurar: no tocar
    let val;
    try { val = window[prop]; } catch (e) { return; }
    if (typeof val !== 'function' || wrapped.has(val)) return;
    try { if (val.toString().indexOf('[native code]') !== -1) return; } catch (e) { return; }

    try {
      const proxy = makeProxy(val, prop);
      Object.defineProperty(window, prop, {
        value: proxy, writable: true, enumerable: desc.enumerable, configurable: true
      });
      if (window[prop] !== proxy) return;
      originals.set(prop, { fn: val, desc });
    } catch (e) { /* blindada: ignorar */ }
  }

  function restoreProp(prop) {
    const o = originals.get(prop);
    if (!o) return;
    try {
      if (wrapped.has(window[prop])) { // solo si sigue siendo NUESTRO proxy
        Object.defineProperty(window, prop, {
          value: o.fn, writable: o.desc.writable !== false, enumerable: o.desc.enumerable, configurable: true
        });
      }
    } catch (e) { /* ignore */ }
    originals.delete(prop);
  }

  // Deja el conjunto envuelto exactamente igual a lo que piden los ajustes.
  function reconcile() {
    // 1. restaurar lo que ya no debe estar envuelto (incluye Tracker OFF)
    for (const prop of Array.from(originals.keys())) {
      if (!shouldWrap(prop)) restoreProp(prop);
    }
    // 2. modo seguro: sin objetivo no se envuelve nada
    if (!isEnabled || (!filterTokens.length && !hookAll)) return;
    // 3. envolver lo que corresponda
    let names;
    try { names = Object.getOwnPropertyNames(window); } catch (e) { return; }
    for (let i = 0; i < names.length; i++) {
      const prop = names[i];
      if (prop === 'window' || prop === 'self' || prop === 'globalThis' || prop === 'top' || prop === 'parent') continue;
      if (originals.has(prop)) continue;
      if (!shouldWrap(prop)) continue;
      wrapProp(prop);
    }
  }

  reconcile();
  setInterval(reconcile, 2000); // captura globals que aparezcan después

  console.log(
    '%c✅ ReconBomb JS Tracker listo (modo seguro: define un filtro para empezar)',
    'color:#fff;background:#10b981;font-weight:bold;padding:4px 8px;border-radius:4px;'
  );
})();
