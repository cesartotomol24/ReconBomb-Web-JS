# ReconBomb Web JS — v3.0

Extensión de Chrome (Manifest V3) para **rastrear la ejecución de funciones
JavaScript en tiempo real** en la pestaña actual: hook con filtro por nombre,
log en consola y registro persistente en **IndexedDB**.

## Instalar (modo desarrollador)
1. `chrome://extensions` → activa **Modo de desarrollador**.
2. **Cargar extensión sin empaquetar** → selecciona la carpeta `ReconBomb-Web-JS`.
3. Fija el icono y abre el popup.

## Modo seguro (no corrompe la página)
Por defecto el tracker **no envuelve ninguna función**. Solo actúa cuando:
- escribes un **objetivo** en el filtro (p. ej. `sendText`), o
- activas el checkbox **«Hook de TODAS»** (power mode, puede afectar la página).

Al apagar el Tracker o quitar un objetivo, las funciones envueltas se
**restauran** a su versión original (con su descriptor). No se intercepta XHR
ni `fetch` (eso daba problemas en la v2).

## Uso
- **Tracker ON/OFF** — activa/desactiva el hook en vivo y restaura originales al apagar.
- **Guardar: ON/OFF** — mientras esté ON, cada llamada capturada se guarda en la
  base de datos del navegador (IndexedDB).
- **Objetivo por nombre** — `sendText` o `sendText, login, fetchUser`.
  Solo se envuelven y registran las funciones que coinciden.
- **Hook de TODAS** — envuelve todos los globals de la página (más ruido/riesgo).
- **Ver registros** — abre `viewer.html`: tabla con hora, función, argumentos,
  estado (ok / resolved / rejected / error), resultado, duración (ms) y URL.
  Buscador en vivo, exportar JSON y limpiar.

Ejemplo: al ejecutarse `sendText("hola", undefined, "canal-3")` verás en consola
`🚀 sendText("hola", "[undefined]", "canal-3")` y, si Guardar está ON, el registro
aparece en el visor.

## Arquitectura
- `injected.js` (mundo MAIN) — envuelve los globals de la página con `Proxy`
  (`apply` + `construct`, conserva `name`/`length`/`prototype`), serializa
  argumentos/resultados de forma segura y acotada, captura resultados sync y
  async, y emite cada llamada por `window.postMessage`.
- `content.js` (mundo ISOLATED) — puente: envía el estado a `injected.js` y
  reenvía las llamadas al service worker cuando «Guardar» está activo.
- `background.js` — service worker: persiste en IndexedDB (`idb.js`).
- `popup.html/js` — controles. `viewer.html/js` — explorador de registros.

## Limitaciones (importante)
- Solo se pueden hookear funciones **alcanzables desde `window`** (globales o
  métodos de objetos globales). Las funciones **dentro de módulos ES o closures**
  no son visibles desde fuera y **no** se pueden interceptar así.
- Envolver con `Proxy` cambia la identidad de la función (`fn === original` da
  `false`); en páginas que comparan referencias esto puede alterar comportamiento.
  Usa el **filtro** para limitar el hook a lo que te interesa.
- Herramienta para **análisis/depuración en sitios propios o con autorización**.
