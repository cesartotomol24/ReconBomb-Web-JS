'use strict';

const $ = (id) => document.getElementById(id);

function render(st) {
  $('toggleBtn').textContent = st.enabled ? '🟢 Tracker: ON' : '⚪ Tracker: OFF';
  $('toggleBtn').className = 'btn ' + (st.enabled ? 'active' : 'inactive');
  $('saveBtn').textContent = st.save ? '💾 Guardar: ON' : '💾 Guardar: OFF';
  $('saveBtn').className = 'btn ' + (st.save ? 'active' : 'inactive');
  if (document.activeElement !== $('filter')) $('filter').value = st.filter || '';
  $('hookAll').checked = st.hookAll === true;
}

function getState(cb) {
  chrome.storage.local.get(['trackerEnabled', 'trackerSave', 'trackerFilter', 'trackerHookAll'], (r) => {
    cb({
      enabled: r.trackerEnabled !== false,
      save: r.trackerSave === true,
      filter: r.trackerFilter || '',
      hookAll: r.trackerHookAll === true
    });
  });
}

async function refreshCount() {
  try { $('count').textContent = await RBDB.count(); }
  catch (e) { $('count').textContent = '0'; }
}

getState(render);
refreshCount();

$('toggleBtn').addEventListener('click', () => {
  getState((st) => {
    const v = !st.enabled;
    chrome.storage.local.set({ trackerEnabled: v }, () => getState(render));
  });
});

$('saveBtn').addEventListener('click', () => {
  getState((st) => {
    const v = !st.save;
    chrome.storage.local.set({ trackerSave: v }, () => getState(render));
  });
});

$('hookAll').addEventListener('change', () => {
  chrome.storage.local.set({ trackerHookAll: $('hookAll').checked });
});

let filterTimer = null;
$('filter').addEventListener('input', () => {
  clearTimeout(filterTimer);
  filterTimer = setTimeout(() => {
    chrome.storage.local.set({ trackerFilter: $('filter').value });
  }, 250);
});

$('viewBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('viewer.html') });
});

$('clearBtn').addEventListener('click', async () => {
  try { await RBDB.clear(); } catch (e) {}
  refreshCount();
});

$('exportBtn').addEventListener('click', async () => {
  let rows = [];
  try { rows = await RBDB.getAll(); } catch (e) {}
  const blob = new Blob([JSON.stringify(rows, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'reconbomb-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
});
