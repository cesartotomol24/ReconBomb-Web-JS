/* background.js — service worker (MV3).
   Recibe las llamadas capturadas desde content.js y las persiste en IndexedDB. */
'use strict';

importScripts('idb.js');

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg && msg.type === 'rb_call' && msg.record) {
    const rec = msg.record;
    // La URL real de la pestaña es más fiable desde el sender.
    if (sender && sender.tab && sender.tab.url) rec.url = sender.tab.url;
    RBDB.add(rec).catch(() => {});
  }
  // No respondemos nada; el canal no necesita respuesta asíncrona.
});

// Valores por defecto al instalar.
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['trackerEnabled', 'trackerSave', 'trackerFilter', 'trackerHookAll'], (r) => {
    const defaults = {};
    if (r.trackerEnabled === undefined) defaults.trackerEnabled = true;
    if (r.trackerSave === undefined) defaults.trackerSave = false;
    if (r.trackerFilter === undefined) defaults.trackerFilter = '';
    if (r.trackerHookAll === undefined) defaults.trackerHookAll = false;
    if (Object.keys(defaults).length) chrome.storage.local.set(defaults);
  });
});
