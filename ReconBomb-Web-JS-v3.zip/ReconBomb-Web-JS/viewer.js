'use strict';

const $ = (id) => document.getElementById(id);
let rows = [];

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

function fmtVal(v) {
  if (v === undefined) return '';
  if (typeof v === 'string') return v;
  try { return JSON.stringify(v, null, 2); } catch (e) { return String(v); }
}

function fmtArgs(args) {
  if (!Array.isArray(args)) return '';
  return args.map(fmtVal).join(',\n');
}

function render(list) {
  if (!list.length) {
    $('body').innerHTML = '<div class="empty">Sin registros. Activa «Guardar en tiempo real» en el popup y ejecuta funciones en la página.</div>';
    return;
  }
  const head =
    '<table><thead><tr>' +
    '<th>Hora</th><th>Función</th><th>Argumentos</th><th>Estado</th><th>Resultado / Error</th><th>ms</th><th>URL</th>' +
    '</tr></thead><tbody>';
  const out = [head];
  for (const r of list) {
    const status = r.status || 'ok';
    const resText = status === 'error' || status === 'rejected' ? (r.error || '') : fmtVal(r.result);
    out.push(
      '<tr>' +
      '<td class="ts">' + esc(new Date(r.ts).toLocaleTimeString()) + '</td>' +
      '<td class="fn">' + (r.ctor ? 'new ' : '') + esc(r.name) + '</td>' +
      '<td class="args"><pre>' + esc(fmtArgs(r.args)) + '</pre></td>' +
      '<td><span class="badge ' + esc(status) + '">' + esc(status) + '</span></td>' +
      '<td class="res"><pre>' + esc(resText) + '</pre></td>' +
      '<td class="ts">' + (r.ms != null ? esc(r.ms) : '') + '</td>' +
      '<td class="url" title="' + esc(r.url || '') + '">' + esc(r.url || '') + '</td>' +
      '</tr>'
    );
  }
  out.push('</tbody></table>');
  $('body').innerHTML = out.join('');
}

function applySearch() {
  const q = $('search').value.trim().toLowerCase();
  if (!q) return render(rows);
  render(rows.filter((r) => {
    const hay = (r.name || '') + ' ' + JSON.stringify(r.args || '') + ' ' +
      JSON.stringify(r.result || '') + ' ' + (r.error || '') + ' ' + (r.url || '');
    return hay.toLowerCase().indexOf(q) !== -1;
  }));
}

async function load() {
  try { rows = await RBDB.getAll(5000); } catch (e) { rows = []; }
  $('count').textContent = rows.length;
  applySearch();
}

$('refresh').addEventListener('click', load);
$('search').addEventListener('input', applySearch);
$('clear').addEventListener('click', async () => {
  try { await RBDB.clear(); } catch (e) {}
  load();
});
$('export').addEventListener('click', () => {
  const blob = new Blob([JSON.stringify(rows, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'reconbomb-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
});

load();
setInterval(load, 3000); // refresco en vivo
