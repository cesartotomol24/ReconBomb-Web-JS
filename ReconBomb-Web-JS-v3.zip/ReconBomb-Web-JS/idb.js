/* idb.js — helper IndexedDB compartido (service worker, popup y visor).
   Script clásico: expone self.RBDB. Mismo origen de extensión => la misma DB
   es visible desde el background, el popup y viewer.html. */
(function (global) {
  'use strict';

  const DB_NAME = 'reconbomb';
  const STORE = 'calls';
  const VERSION = 1;
  let dbPromise = null;

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          const os = db.createObjectStore(STORE, { keyPath: 'id', autoIncrement: true });
          os.createIndex('ts', 'ts');
          os.createIndex('name', 'name');
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
    return dbPromise;
  }

  async function add(record) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).add(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  // Más recientes primero. limit opcional.
  async function getAll(limit) {
    const db = await open();
    return new Promise((resolve, reject) => {
      const out = [];
      const tx = db.transaction(STORE, 'readonly');
      const cursor = tx.objectStore(STORE).index('ts').openCursor(null, 'prev');
      cursor.onsuccess = () => {
        const c = cursor.result;
        if (c && (!limit || out.length < limit)) {
          out.push(c.value);
          c.continue();
        } else {
          resolve(out);
        }
      };
      cursor.onerror = () => reject(cursor.error);
    });
  }

  async function count() {
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const r = tx.objectStore(STORE).count();
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => reject(r.error);
    });
  }

  async function clear() {
    const db = await open();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  global.RBDB = { add, getAll, count, clear };
})(self);
